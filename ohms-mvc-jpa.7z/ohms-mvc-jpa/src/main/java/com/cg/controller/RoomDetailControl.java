package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.HotelDetailsDto;
import com.cg.bean.RoomDetailsDto;
import com.cg.service.IRoomDetailsService;
import com.cg.service.IService;

@RestController
public class RoomDetailControl {

	@Autowired
	IService service;
	
    public void setService(IService service) {
		this.service = service;
	}

	public void setRoomdata(RoomDetailsDto roomdata) {
		this.roomdata = roomdata;
	}

	RoomDetailsDto roomdata=new RoomDetailsDto();
	
	@RequestMapping(value = "/addroomdetail", method = RequestMethod.POST,consumes="application/json", produces = "application/json")
	public RoomDetailsDto roomDetailsDto(@RequestBody RoomDetailsDto roomDetailsDto) {
	RoomDetailsDto result=null;
	try {
     result=service.addDetail(roomDetailsDto.getRoom_id(),roomDetailsDto.getNumber_of_persons(),
    		 roomDetailsDto.getRoomtype(),roomDetailsDto.getPrice());
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	return roomDetailsDto;
	}

	
}
	

