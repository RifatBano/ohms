package com.cg.Exception;

public class RoomDetailsValidationException {

public static final String DETAILS_EXCEPTION="Please give the proper values";
public static final String MESSAGE="Sorry!! Unwanted inturruption occures";
public static final String MESSAGE2="connection error!!";
public static final String ROOMIDEXCEPTIONMESSAGE="roomid should only contain integer and maximum length should be 6-digits and it should not be repeated";
public static final String NUMBEROFPERSONSEXCEPTIONMESSAGE="number of persons should be integer of maximum 2-digit";
public static final String ROOMTYPEEXCEPTIONMESSAGE="roomtype should be string of maximum size 20";
public static final String PRICEEXCEPTIONMESSAGE="maximum 7-digit are of type integer are allowed including upto 2-decimal palces";
public static final String HOTELIDEXCEPTIONMESSAGE="hotelid should only contain integer and maximum length should be 6-digits";
}
