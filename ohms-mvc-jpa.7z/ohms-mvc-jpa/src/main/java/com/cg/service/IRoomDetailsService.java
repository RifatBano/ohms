package com.cg.service;

import java.sql.SQLException;
import com.cg.Exception.RoomDetailException;
import com.cg.bean.HotelDetailsDto;
import com.cg.bean.RoomDetailsDto;


/*
 * creating an interface of service layer
 */
public interface IRoomDetailsService {
	String deleteRoomDetails(int roomid) throws SQLException, RoomDetailException;
	String updateRoomPrice(double price,int roomid) throws SQLException, RoomDetailException ;
	//void addRoomDetails(HotelDetailsDto hoteldetail, RoomDetailsDto roomdetails) throws Exception, RoomDetailException;

}
