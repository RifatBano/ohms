package com.cg.service;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Exception.RoomDetailException;
import com.cg.bean.HotelDetailsDto;
import com.cg.bean.RoomDetailsDto;
import com.cg.dao.IRoomDetailsDao;
import com.cg.dao.RoomDetailsDaoImpl;

//this is the implementation class of service Interface (IBooking)

@Service
public class RoomDetailsServiceImpl implements IRoomDetailsService{	
	//we are creating object of IOperationalDao Interface 
	@Autowired
	IRoomDetailsDao operationalquery;
	
	public void setOperationalquery(IRoomDetailsDao operationalquery) {
		this.operationalquery = operationalquery;
	}
	//addRoomDetails() function is called by the main()
	//@Override
//public void addRoomDetails(HotelDetailsDto hoteldetail, RoomDetailsDto roomdetails) throws Exception, RoomDetailException {
//		// TODO Auto-generated method stub	
//		hoteldetail.addRoomDetail(roomdetails);
//		operationalquery.queryForAdd(hoteldetail);
//	 
//	}
//deleteRoomDetails function is called by the main()
//	@Override
//	public String deleteRoomDetails(int roomid) throws SQLException, RoomDetailException {
//		
//		// TODO Auto-generated method stub
//		//deleting through roomid
//		System.out.println(roomid);
//		String result2=operationalquery.queryForDelete(roomid);
//		
//		return result2;
//	}

	@Override
	public String deleteRoomDetails(int roomid) throws SQLException, RoomDetailException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateRoomPrice(double price, int roomid) throws SQLException, RoomDetailException {
		// TODO Auto-generated method stub
		return null;
	}

//updateRoomPrice function is called by the main()
//	@Override
//	public String updateRoomPrice(double price,int roomid) throws SQLException, RoomDetailException {
//	
//		// TODO Auto-generated method stub
//		//update the Room Price
//		String result4=operationalquery.queryForUpdatePrice(price, roomid);
//		return result4;
//	}


	
	
	
	
	
}

