package com.cg.service;

import java.util.List;

import com.cg.Exception.RoomDetailException;
import com.cg.bean.RoomDetailsDto;

public interface IService {

	  
  
   // public List<RoomDetailsDto> getAllDetails();
 
    public void deleteDetail(Integer room_id);
 
  //  public RoomDetailsDto getDetail(int room_id);
 
    public RoomDetailsDto updatePrice(RoomDetailsDto roomdetail);

	public RoomDetailsDto addDetail(int room_id, int number_of_persons, String roomtype, double price) throws RoomDetailException;
}
