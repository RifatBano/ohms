package com.cg.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Exception.RoomDetailException;
import com.cg.bean.RoomDetailsDto;
import com.cg.dao.IDetailDao;
@Service
@Transactional
public class ServiceImpl implements IService{

	@Autowired
	IDetailDao detail;

	RoomDetailsDto roomdata=new RoomDetailsDto();
	public RoomDetailsDto addDetail(int room_id, int number_of_persons, String roomtype, double price) throws RoomDetailException {
		// TODO Auto-generated method stub
		roomdata.getRoom_id();
		roomdata.getNumber_of_persons();
		roomdata.getRoomtype();
		roomdata.getPrice();
		
		
		return detail.addDetail(roomdata);
	}
//	
////
////	@Override
////	public List<RoomDetailsDto> getAllDetails() {
////		// TODO Auto-generated method stub
////		return null;
////	}
//
//	@Override
//	public void deleteDetail(Integer room_id) {
//		// TODO Auto-generated method stub
//		
//		
//	}
//
////	@Override
////	public RoomDetailsDto getDetail(int room_id) {
////		// TODO Auto-generated method stub
////		return null;
////	}
//
//	@Override
//	public RoomDetailsDto updatePrice(RoomDetailsDto roomdetail) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	

	@Override
	public void deleteDetail(Integer room_id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public RoomDetailsDto updatePrice(RoomDetailsDto roomdetail) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RoomDetailsDto addDetail(int room_id, int number_of_persons, String roomtype, double price) {
		// TODO Auto-generated method stub
		return null;
	}

}
