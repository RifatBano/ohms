package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

import com.cg.Exception.RoomDetailException;
import com.cg.Exception.RoomDetailsValidationException;
import com.cg.bean.RoomDetailsDto;

@Repository
public class DetailDaoImpl implements IDetailDao{
	private EntityManagerFactory emf=Persistence.createEntityManagerFactory("qwe");
	private EntityManager em=emf.createEntityManager();
	private EntityTransaction etx=em.getTransaction();
	
	RoomDetailsDto roomdetails=new RoomDetailsDto();
	@Override
	public void addDetail(RoomDetailsDto roomdetail) throws RoomDetailException {
		
		try {
		    etx.begin();
		    em.persist(roomdetail);
		    etx.commit();
			}
			catch(Exception e)
			{
				throw new RoomDetailException(RoomDetailsValidationException.MESSAGE);
			}
		
	}

	@Override
	public void deleteDetail(Integer room_id) throws RoomDetailException {
		// TODO Auto-generated method stub

		roomdetails=em.find(RoomDetailsDto.class, room_id);
		if(roomdetails!=null)
		{
			try {
			etx.begin();
			em.remove(roomdetails);
			etx.commit();
			}
			catch(Exception e)
			{
				throw new RoomDetailException(RoomDetailsValidationException.MESSAGE);
			}
		}
		
	}

	@Override
	public RoomDetailsDto updatePrice(RoomDetailsDto roomdetail) {
		// TODO Auto-generated method stub
		return null;
	}

}
