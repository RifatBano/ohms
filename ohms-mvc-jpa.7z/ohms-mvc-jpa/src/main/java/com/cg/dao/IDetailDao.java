package com.cg.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.Exception.RoomDetailException;
import com.cg.bean.RoomDetailsDto;

public interface IDetailDao {
	  

    public void deleteDetail(Integer room_id) throws RoomDetailException;
 
    public RoomDetailsDto updatePrice(RoomDetailsDto roomdetail);

	public RoomDetailsDto addDetail(RoomDetailsDto rooDetailsDto) throws RoomDetailException;
}
