package com.cg.dao;


import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.Exception.RoomDetailException;
import com.cg.Exception.RoomDetailsValidationException;
import com.cg.bean.HotelDetailsDto;
import com.cg.bean.RoomDetailsDto;

@Repository
public class RoomDetailsDaoImpl implements IRoomDetailsDao {

	private EntityManagerFactory emf=Persistence.createEntityManagerFactory("qwe");
	private EntityManager em=emf.createEntityManager();
	private EntityTransaction etx=em.getTransaction();
	
	//TypedQuery<RoomDetailsDto> query=em.
	RoomDetailsDto roomdetails=new RoomDetailsDto();
//	HotelDetailsDto hotel=new HotelDetailsDto();
   @Override
	public void queryForAdd(HotelDetailsDto hoteldetail) throws SQLException, RoomDetailException {
		// TODO Auto-generated method stub
		try {
	    etx.begin();
	    em.persist(hoteldetail);
	    etx.commit();
		}
		catch(Exception e)
		{
			throw new RoomDetailException(RoomDetailsValidationException.MESSAGE);
		}
	}
	
@Override
	public void queryForDelete(int roomid) throws SQLException, RoomDetailException {
		// TODO Auto-generated method stub
	
	roomdetails=em.find(RoomDetailsDto.class, roomid);
	if(roomdetails!=null)
	{
		try {
		etx.begin();
		em.remove(roomdetails);
		etx.commit();
		}
		catch(Exception e)
		{
			throw new RoomDetailException(RoomDetailsValidationException.MESSAGE);
		}
	}
		
	}

	@Override
	public void queryForUpdatePrice(double raiseprice, int roomid) throws SQLException, RoomDetailException {
		// TODO Auto-generated method stub
		
		roomdetails=em.find(RoomDetailsDto.class, roomid);
		if(roomdetails!=null)
		{
			try {
				try {
				etx.begin();
				roomdetails.setPrice(roomdetails.getPrice());
				etx.commit();
}
catch(Exception e)
{
				throw new RoomDetailException(RoomDetailsValidationException.MESSAGE);
}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
				
		
	}


	
	
}
