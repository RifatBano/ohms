package com.cg.dao;

import java.sql.SQLException;

import com.cg.Exception.RoomDetailException;
import com.cg.bean.HotelDetailsDto;
import com.cg.bean.RoomDetailsDto;


/*
 * creating interface of data access object layer
 */
public interface IRoomDetailsDao {

	public void queryForDelete(int roomid) throws SQLException, RoomDetailException;
	//public String queryForUpdatePerson(int person,int roomid) throws SQLException;
	public void queryForUpdatePrice(double price,int roomid) throws SQLException, RoomDetailException;
	public void queryForAdd(HotelDetailsDto hotel) throws SQLException, RoomDetailException;
}
